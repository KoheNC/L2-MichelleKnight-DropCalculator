<?php
header("Content-Type: image/jpg");
include('config.php');
$image_loc =  $images_loc_dir . 'gd' . $svr_dir_delimit . 'dff.jpg';
$im = imagecreatefromjpeg($image_loc);
imagegif($im);
?>