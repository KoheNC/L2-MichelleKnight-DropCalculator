<?php

// HTML colour codes for the standard red, green and blue character displays, and also the
// colour and background colour for the pop up boxes.

$red_code = "#aa0000";
$green_code = "#00aa00";
$blue_code = "#C600C6";
$yellow_code = "#ffff00";
$white_code = "#ffffff";

$pop_up_background = "#000000";
$pop_up_color = "#eeeeee";

$clog_shout = "#c78354";
$clog_all = "#fffdf9";
$clog_tell = "#be45b9";
$clog_trade = "#d8a3cf";
$clog_clan = "#948ad1";
$clog_party = "#08fb09";
$clog_hero = "#3890fa";
$clog_alliance = "#a0fbca"; 

?>