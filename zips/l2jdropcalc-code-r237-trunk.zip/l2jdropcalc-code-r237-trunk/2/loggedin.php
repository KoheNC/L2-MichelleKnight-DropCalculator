<?php 
echo "<p class=\"dropmain\">&nbsp;</p>
<h2 class=\"dropmain\">Welcome to the drop calc.</h2>
<center><hr width=\"30%\"></center>
<h2 class=\"dropmain\">Server - Michelle's Test Server</h2>
<p class=\"maincenter\">No special anouncements at present.</p>
<p class=\"maincenter\">Enjoy your game!</p>
<center><hr width=\"30%\"></center>
<h2 class=\"dropmain\">Dropcalc special features</h2>
<table cellpadding=\"5\" cellspacing=\"0\" border=\"0\"><tr><td>
<p class=\"dropmainwhite\" valign=\"top\"><img src=\"" . $images_dir . "exp1.jpg\" width=\"172\" height=\"88\" align=\"right\">If you are suffering the problem where your client crashes whenever you select your character, or you are otherwise stuck in a wall and there is no GM around, then if your administrator has enabled the emergency teleport, you can use this button to teleport your character back to their hometown.  The character must be offline before you can see the button.</p>
</td></tr></table>
<center><hr width=\"30%\"></center>
<table cellpadding=\"5\" cellspacing=\"0\" border=\"0\"><tr><td valign=\"top\">
<p class=\"dropmainwhite\">If your administrator has allowed you access to the character changing facility, then if your character is offline, then the button will appear in between your detailed character statistics.  On pressing it, you will be taken to the alteration screen, where you must be aware that anything you click on, will instantly change your character.  That includes the sex buttons to the left and right of the character title.</p>
<p class=\"dropmainwhite\">The blue surround will show you the currently selected face and hair style.</p>
<center><img src=\"" . $images_dir . "exp2.jpg\" width=\"300\" height=\"122\"></center>
</td><td><img src=\"" . $images_dir . "exp3.jpg\" width=\"300\" height=\"249\">
</td></tr></table>
<center><hr width=\"30%\"></center>
<table cellpadding=\"5\" cellspacing=\"0\" border=\"0\"><tr><td>
<p class=\"dropmainwhite\" valign=\"top\"><img src=\"" . $images_dir . "exp4.jpg\" width=\"300\" height=\"89\" align=\"right\">The calculator symbol, when next to a recipe, tells you that you have access to the recipe calculator.  The calculator will go through either your own characters (a brown calculator) or the characters that are a member of your clan (green calculator) and will give you the results of who has what ingredients, how many more you need, and also if there are any other recipes to make that ingredient from lower level mats.</p>
</td></tr><tr><td><center><img src=\"" . $images_dir . "exp5.jpg\" width=\"600\" height=\"499\"></center></td></tr></table>
"; 
?>