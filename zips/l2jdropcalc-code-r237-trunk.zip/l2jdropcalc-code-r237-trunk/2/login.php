<?php 
echo "<p class=\"dropmain\">&nbsp;</p>
<p class=\"dropmain\">&nbsp;</p>
<p class=\"dropmain\">&nbsp;</p>
<h2 class=\"dropmain\">Welcome to Michelle's L2J drop calc.</h2>
<center><hr width=\"30%\"</center>
<h2 class=\"dropmain\">Lineage 2</h2>
<center><hr width=\"30%\"</center>	
<p class=\"maincenter\">Dropcalc Engine - V4</p>
<p class=\"maincenter\">Programmed by Michelle Knight of <a href=\"http://www.msknight.com\" target=\"new\" class=\"mainmenu\">MSKnight.com</a>
<br>Default skin by Jam of <a href=\"http://www.borntwisted.com\" target=\"new\" class=\"mainmenu\">BornTwisted.com</a><br>with help from PCPro32
<br>Seven Signs \"clock\" by Daedalus.
<br>Icons for skills and items used with permission from <a href=\"http://www.l2wh.com\" target=\"new\" class=\"mainmenu\">http://www.l2wh.com</a>
<br>IP Geographic data used with permission from <a href=\"http://www.maxmind.com\" target=\"new\" class=\"mainmenu\">http://www.maxmind.com</a>
<br>Pictures of the monsters by kind contribution of nBd and Foxy.
<br>Lineage II icons and graphics are (c) NCSOFT corporation</p>
<p class=\"dropmain\">&nbsp;</p>
<h2 class=\"dropmain\">Thanks to : </h2>
<p class=\"maincenter\">Virtuoso, Nic, Reya, KMK, Sodoku, ManO, PanFrie, CrazyCommie and all at iGO, <br>Law, HeXa, Fulminus, ceco78, ethann, sm4sh, miya, Cyberfox, Enforcer, makaron, MachZERO,<br>taneltm, vb2005, snakesk, kadar, ThePhoenixBird, shansoft, aresxp, Bjorkker, Paul Atrides,<br>Kmarty, Kion le Fou, TheSaint, LkMsWb, elachlan, Loup_Solitaire, Nico, Melerix,<br>... and all at the L2J server and datapack teams ...<br>for the invaluable help with testing, ideas, digging up code and reference texts<br>and generally breaking the system while I was trying to write it ! :-)</p>
<p class=\"dropmain\">&nbsp;</p>
<center><img src=\"" . $images_dir . "bg_foot.gif\"></center>
"; 

?>