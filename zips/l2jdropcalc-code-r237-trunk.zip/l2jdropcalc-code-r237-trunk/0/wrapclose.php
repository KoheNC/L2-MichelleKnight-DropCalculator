<?php
echo "
<!-- Footer -->

</td><td><img src=\"$skin_dir/blank.gif\" height=\"1\" width=\"10\"></td></tr></table></td></tr></table></td></tr></table>
<!-- End Content -->
</body>
</html>
";

?>