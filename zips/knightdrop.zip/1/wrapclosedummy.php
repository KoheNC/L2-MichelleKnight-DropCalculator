<?php
echo "
<!-- Footer -->

</td><td style=\"background:url('$skin_dir/keybd-right.jpg');\"></td></tr>
<tr><td class=\"back2\"><img src=\"$skin_dir/keybd-corner.jpg\" alt=\"\" width=\"58\" height=\"58\" border=\"0\"></td><td style=\"background:url('$skin_dir/keybd-bot.jpg');\" width=\"100%\"></td><td class=\"back2\"><img src=\"$skin_dir/keybd-corner.jpg\" alt=\"\" width=\"58\" height=\"58\" border=\"0\"></td></tr>
</table></td><td><img src=\"$skin_dir/blank.gif\" height=\"1\" width=\"5\"></td></tr></table></td></tr></table></td></tr></table>
<!-- End Content -->
</body>
</html>
";


?>