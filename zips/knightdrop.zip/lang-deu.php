
<?php
/*
Michelle Knight's Drop Calc - Version 3
Author - Michelle Knight
Copyright 2006
Contact - dropcalc@msknight.com

GNU General Licence
Use and distribute freely, but leave headers intact and make no charge.
Change HTML code as necessary to fit your own site.
Code distributed without warantee or liability as to merchantability as
no charge is made for its use.  Use is at users risk.
*/

/*
	IF CONTRIBUTING ANOTHER LANGUAGE ...
	Please use the html & symbol code wherever possible to ensure that your language code stays intact
	... they can be found here ... http://www.ascii.cl/htmlcodes.htm 
*/

//Skin Menu
$lang_welcome = "Willkommen";
$lang_online = "Sind Online";
$lang_language = "Sprache";
$lang_logout = "Abmelden";
$lang_items = "Gegenst&auml;nde";
$lang_chars = "Charaktere";
$lang_clans = "Clans";
$lang_mobs = "Kreaturen";
$lang_account = "Konto";
$lang_locations = "Position";
$lang_recipes = "Rezepte";
$lang_skills = "Fertigkeiten";
$lang_welcome = "Wilkommen";
$lang_usern = "Benutzername";
$lang_passwd = "Passwort";
$lang_reg_acc = "Konto erstellen";
$lang_guest_login = "Gast Anmeldung";
$lang_faq = "Fragen und Antworten";
$lang_newbguide = " Anleitung f&uuml;r Neulinge";
$lang_connecting = "Verbindung zu L2J";
$lang_whosonline = "Wer ist online?";
$lang_mobsbylvl = "Kreaturen nach Lvl";
$lang_itemsbytype = "Gegens&auml;nde nach Typen";
$lang_trustedp = "Vertrauensw&uuml;dige Spieler";
$lang_classtree = "Klassen Baum";
$lang_caststat = "Status der Festungen";
$lang_sevens = "Status der 7 Siegel";
$lang_topten = "Beste Spieler";
$lang_changep = "Passwort &auml;ndern";
$lang_gmref = "GM Hinweise";
$lang_servertools = "Server&nbsp;Werkzeuge";
$lang_serverconsole = "Server&nbsp;Konsole";
$lang_serverstats = "Server&nbsp;Statistiken";
$lang_chatlog = "Chat&nbsp;Protokoll";
$lang_shops = "L&auml;den";
$lang_pets = "Haustiere";
$lang_databaseu = "Datenbank&nbsp;Werkzeuge";
$lang_announcements = "Ank&uuml;ndigungen";
$lang_loginc = "Anmeldungs&nbsp;Konsole";
$lang_loginevent = "Anmeldungs&nbsp;Ereignisse";
$lang_itemlog = "Gegenstands&nbsp;Protokoll";
$lang_gmaudit = "GM-Kontroll&nbsp;Protokoll";

//Races
$lang_human = "Mensch";
$lang_elf = "Elf";
$lang_delf = "Dunkel Elf";
$lang_orc = "Ork";
$lang_dwarf = "Zwerg";
$lang_kamael = "Kamael";

$lang_monday = "Monday";
$lang_tuesday = "Tuesday";
$lang_wednesday = "Wednesday";
$lang_thursday = "Thursday";
$lang_friday = "Friday";
$lang_saturday = "Saturday";
$lang_sunday = "Sunday";

$lang_unknown = "Unknown";
$lang_none = "None";
$lang_dawn = "Dawn";
$lang_dusk = "Dusk";
$lang_stones = "Stones";
$lang_festival = "Festival";
$lang_total = "Total";
$lang_points = "Points";
$lang_name = "Name";
$lang_undead = "Undead";
$lang_type = "Type";
$lang_spawn = "Spawn";
$lang_sct = "Select Character Type";
$lang_armour = "Armour";
$lang_weapon = "Weapon";
$lang_other = "Other";
$lang_accessories = "Accessories";
$lang_warehouse = "Warehouse";
$lang_freight = "Freight";
$lang_inventory = "Inventory";
$lang_wearing = "Wearing";
$lang_sarmour = "Select Armour";
$lang_sweapon = "Select Weapon";
$lang_sother = "Select Item";
$lang_saccessories = "Select Accessory";
$lang_tdwarves = "Trusted Dwarves";
$lang_tothers = "Trusted Others";
$lang_castle = "Castle";
$lang_owner = "Owner";
$lang_stime = "Siege Time";
$lang_sday = "Siege Day";
$lang_karma = "Karma";
$lang_level = "Level";
$lang_character = "Character";
$lang_clan = "Clan";
$lang_name = "Name";
$lang_password = "Password";
$lang_confirm = "Confirm";
$lang_createacc = "Create Account";
$lang_signin = "Sign In";
$lang_day = "Day";
$lang_night = "Night";
$lang_always = "Always";
$lang_mapkey = "Map Key";
$lang_tax = "Tax";
$lang_itemview = "Item View";
$lang_skillview = "Skill View";
$lang_recipeview = "Recipe View";
$lang_pguandp = "Please give a user name and password";
$lang_passillchar = "Illegal characters in password.<br>Stick to alphanumeric.";
$lang_passilluchar = "Illegal characters in username.<br>Stick to alphanumeric and underscores.";
$lang_pass_noguest = "Can't use Guest as a username.";
$lang_pass_minthree = "Password needs to be minimum three characters.";
$lang_pass_nomatch = "Passwords don't match.";
$lang_pass_length = "Account name exceeds maximum length of";
$lang_pass_userexist = "Username already exists.";
$lang_pass_suceed = "Password change suceeded!";

$lang_itemtype = "Item&nbsp;Type";
$lang_arm_and_a = "Armour &amp; Acessories";
$lang_clanwareh = "Clan Warehouse";
$lang_clanwarehemp = "Clan Warehouse is empty.";
$lang_equipped = "Equipped";
$lang_invendissable = "Admin has dissabled viewing inventory of other characters.";
$lang_clanifinddis = "The administrator has disabled Clan Item Find.";
$lang_clancalc = "Clan Calculation";
$lang_class = "Class";

$lang_settings = "Dropcalc&nbsp;Settings";
$lang_leader = "Leader";
$lang_makeleader = "Make Leader";
$lang_hideout = "Hideout";
$lang_ally = "Ally";
$lang_lastlogon = "Last Logon";
$lang_erasename = "Erase Name";

$lang_server = "Server";
$lang_skin = "Skin";
?>