<?php
echo "
<!-- Footer -->

</td><td class=\"backcr\"></td></tr>
<tr><td class=\"back2\"><img src=\"$skin_dir/c-bl.jpg\" alt=\"\" width=\"23\" height=\"23\" border=\"0\"></td><td class=\"backcb\" width=\"100%\"></td><td class=\"back2\"><img src=\"$skin_dir/c-br.jpg\" alt=\"\" width=\"23\" height=\"23\" border=\"0\"></td></tr>
</table></td></tr></table></td></tr></table></td></tr></table>
<!-- End Content -->
</body>
</html>
";

?>