<?php
echo "
<!-- Footer -->

</td><td><img src=\"$skin_dir/blank.gif\" height=\"1\" width=\"20\"></td></tr></table>
<!-- End Content -->
</body>

</html>
";

?>